<button type="button" class="btn bg-gradient-{{$status}} mr-1 mb-1 waves-effect waves-light">{{$statusTxt}}</button>
