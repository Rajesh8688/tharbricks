
<?php $__env->startSection('content'); ?>
<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <!-- Dashboard Analytics Start -->
            <section id="dashboard-analytics">
                <div class="row match-height ">
                    <!-- Description lists horizontal -->
                    <div class="col-sm-12 col-md-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"><?php echo e(__('lang.total_customer')); ?></h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="card-text">
                                        <dl class="row">
                                            <dt class="col-sm-7 col-7"> <?php echo e(__('lang.app')); ?> :</dt>
                                            <dd class="col-sm-5 col-5"> <?php echo e($dashboardDetails['appCustomers']); ?> </dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-7 col-7"> <?php echo e(__('lang.web')); ?> :</dt>
                                            <dd class="col-sm-5 col-5"> <?php echo e($dashboardDetails['webCustomers']); ?> </dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-7 col-7"> <?php echo e(__('lang.guest')); ?> :</dt>
                                            <dd class="col-sm-5 col-5"> <?php echo e($dashboardDetails['guestCustomers']); ?> </dd>
                                        </dl>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ Description lists horizontal-->
                    <!-- Description lists horizontal -->
                    <div class="col-sm-12 col-md-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> <?php echo e(__('lang.total_bookings')); ?>  </h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="card-text">
                                        <dl class="row">
                                            <dt class="col-sm-7 col-7"><?php echo e(__('lang.total')); ?> :</dt>
                                            <dd class="col-sm-5 col-5"><?php echo e($dashboardDetails['totalBookings']); ?></dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-7 col-7"><?php echo e(__('lang.confirmed')); ?> :</dt>
                                            <dd class="col-sm-5 col-5"> <?php echo e($dashboardDetails['confirmedBookings']); ?></dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-7 col-7"><?php echo e(__('lang.canceled')); ?> :</dt>
                                            <dd class="col-sm-5 col-5"> 0 </dd>
                                        </dl>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ Description lists horizontal-->
                    <!-- Description lists horizontal -->
                    <div class="col-sm-12 col-md-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"><?php echo e(__('lang.total_sales')); ?> </h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="card-text">
                                        <dl class="row">
                                            <dt class="col-sm-5 col-5"><?php echo e(__('lang.total')); ?> :</dt>
                                            <dd class="col-sm-7 col-7"> <?php echo e($dashboardDetails['totalSales']); ?> </dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-5 col-5"><?php echo e(__('lang.web')); ?> :</dt>
                                            <dd class="col-sm-7 col-7"> <?php echo e($dashboardDetails['websales']); ?> </dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-5 col-5"><?php echo e(__('lang.app')); ?> :</dt>
                                            <dd class="col-sm-7 col-7"> <?php echo e($dashboardDetails['appsales']); ?> </dd>
                                        </dl>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ Description lists horizontal-->
                    <!-- Description lists horizontal -->
                    <div class="col-sm-12 col-md-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"> <?php echo e(__('lang.total_statistics')); ?> </h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="card-text">
                                        <dl class="row">
                                            <dt class="col-sm-7 col-4"> <?php echo e(__('lang.customers')); ?> :</dt>
                                            <dd class="col-sm-5 col-8"> <?php echo e($dashboardDetails['totalCustomers']); ?> </dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-7 col-4"><?php echo e(__('lang.booking')); ?> :</dt>
                                            <dd class="col-sm-5 col-8"> <?php echo e($dashboardDetails['totalBookings']); ?> </dd>
                                        </dl>
                                        <dl class="row">
                                            <dt class="col-sm-7 col-4"><?php echo e(__('lang.sales')); ?> :</dt>
                                            <dd class="col-sm-5 col-8"> <?php echo e($dashboardDetails['totalSales']); ?> </dd>
                                        </dl>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ Description lists horizontal-->

                   
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking-view')): ?>
                <div class="row">
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-content">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table class="table zero-configuration">
                                            <thead>
                                            <tr>
                                                <th>Sr</th>
                                                <th>Galileo Id</th>
                                                <th>Customer</th>
                                                <th>Phone No</th>
                                                <th>Total Price</th>
                                                <th>PNR</th>
                                                <th>Status</th>
                                                <th>Created at</th>
                                                <th>Actions</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            <?php if(count($dashboardDetails['bookings']) > 0): ?>
                                                <?php $__currentLoopData = $dashboardDetails['bookings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?> </td>
                                                    <td><?php echo e($booking->galileo_pnr); ?> </td>
                                                    <td><?php echo e($booking->TravelersInfo[0]->first_name ?? ''); ?>&nbsp;<?php echo e($booking->TravelersInfo[0]->last_name ?? ''); ?> </td>
                                                    <td><?php echo e($booking->Customercountry->phone_code ?? ''); ?> &nbsp;<?php echo e($booking->mobile); ?> </td>
                                                    <td><?php echo e($booking->currency_code); ?>&nbsp; <?php echo e($booking->total_amount); ?> </td>
                                                    <td><?php echo e($booking->pnr); ?> </td>
                                                    <td><?php echo e(str_replace("_"," ",$booking->booking_status)); ?></td>
                                                    <td><?php echo e($booking->created_at->format('d/m/Y')); ?> </td>
                                                    <td>
                                                        <?php if(!empty($booking->flight_ticket_path)): ?>
                                                        <a  href = "<?php echo e(asset($booking->flight_ticket_path)); ?>" download data-bs-toggle="tooltip" title="Download Ticket"><i class="fa fa-download"></i></a> | 
                                                        <?php endif; ?>
                                                        <?php if(!empty($booking->invoice_path)): ?>
                                                        <a  href = "<?php echo e(asset($booking->invoice_path)); ?>" download data-bs-toggle="tooltip" title="Download Invoice"><i class="fa fa-file-pdf-o"></i></a> | 
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking-cancel')): ?>
                                                        <?php if($booking->ticket_status == 1 && ($booking->booking_status == "booking_completed" || $booking->booking_status == "cancellation_initiated") && $booking->is_cancel != 1): ?>
                                                        <a  href = "javascript:"  onclick="cancle(<?php echo e($booking->id); ?>)" data-id="<?php echo e($booking->id); ?>"data-bs-toggle="tooltip" title="Cancle / Reschedule" data-toggle="modal" data-target="#cancleModel" id="canclebtn"><i class="fa fa-times-circle"></i></a>
                                                        <?php endif; ?>
                                                        <?php endif; ?>
                                                    </td>
                                                   
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr align="center" class="alert alert-danger">
                                                    <td colspan="9">No Record(s)</td>
                                                </tr>
                                            <?php endif; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
                <?php endif; ?>
               
            </section>
            <!-- Dashboard Analytics end -->

        </div>
    </div>
</div>
<!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extrascript'); ?>
    <script>


        <?php if(session('success')): ?>
        toastr.success('<?php echo e(session('success')); ?>', 'Success');
        <?php endif; ?>
        <?php if(session('error')): ?>
        toastr.error('<?php echo e(session('error')); ?>', 'Error');
        <?php endif; ?>


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tharbricks\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>