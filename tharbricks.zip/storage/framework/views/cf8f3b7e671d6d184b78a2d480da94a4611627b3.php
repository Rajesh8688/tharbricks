

<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin-breadcrumb','data' => ['title' => $titles['title']]]); ?>
<?php $component->withName('admin-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($titles['title'])]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <div class="content-body">
                <section class="invoice-print mb-1">
                    <div class="row">
                        <div class="col-12 col-md-12 d-flex flex-column flex-md-row justify-content-end">
                            <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary btn-print mb-1 mb-md-0"><i
                                    class="feather icon-plus-circle"></i>&nbsp;Add Category</a>
                            </a>
                        </div>
                    </div>
                </section>

             

                <!-- List Datatable Starts -->
                <section id="basic-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title"><?php echo e($titles['listTitle']); ?></h4>
                                </div>
                                <div class="card-content">
                                    <div class="card-body card-dashboard">
                                        <div class="table-responsive">
                                            <table class="table zero-configuration">
                                                <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Icon</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                                </thead>
                                                <tbody>

                                                <?php if(count($categories) > 0): ?>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($category->name); ?></td>
                                                            <td class="product-img">
                                                                <img
                                                                    src="<?php echo e($category->icon ?  asset('uploads/categories/icons/'.$category->icon) : $noImage); ?> "
                                                                    width="44"/>
                                                            </td>
                                                            <td><?php echo e($category->status); ?></td>
                                                            <td>
                                                          
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-update')): ?>
                                                                    <a href="<?php echo e(route('category.edit', $category->id)); ?>"><i
                                                                            class="feather icon-edit"></i> Edit</a> |
                                                                <?php endif; ?>

                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-delete')): ?>
                                                                    <a href="javascript:" class="text-danger deleteBtn"
                                                                       onclick="destroy(<?php echo e($category->id); ?>)"
                                                                       data-id="<?php echo e($category->id); ?>"
                                                                       data-toggle="modal"
                                                                       data-target="#deleteModal" id="deleteBtn"><i
                                                                            class="feather icon-trash"></i> Delete</a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr align="center" class="alert alert-danger">
                                                        <td colspan="4">No Record(s)</td>
                                                    </tr>
                                                <?php endif; ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- List Datatable Ends -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrascript'); ?>
    <script>
        $('.zero-configuration').DataTable(
            {
                "displayLength": 50,
            }
        );

        <?php if(session('success')): ?>
        toastr.success('<?php echo e(session('success')); ?>', 'success');
        <?php endif; ?>
        <?php if(session('error')): ?>
        toastr.error('<?php echo e(session('error')); ?>', 'error');
        <?php endif; ?>

        // Functionality section
        function destroy(delId) {
            let url = '<?php echo e(route("category.destroy", ":id")); ?>';
            url = url.replace(':id', delId);
            $("#deleteForm").attr('action', url);
            $("#delete_id").val(delId);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tharbricks\resources\views/admin/category/index.blade.php ENDPATH**/ ?>