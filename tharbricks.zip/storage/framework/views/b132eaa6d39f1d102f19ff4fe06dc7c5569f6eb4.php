

<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin-breadcrumb','data' => ['title' => $title]]); ?>
<?php $component->withName('admin-breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <div class="content-body">


                <!-- Form Starts -->
                <section id="multiple-column-form">
                    <div class="row match-height">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">General Info</h4>
                                </div>
                                <div class="card-content">
                                    <div class="card-body">
                                        <form class="form" method="post" action="<?php echo e(route('admin.settings.update')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="sitename" class="form-control"
                                                                   placeholder="Website Name"
                                                                   name="sitename"
                                                                   value="<?php echo e($settings->sitename); ?>">
                                                            <label for="first-name-column">Website Name
                                                                </label>
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <div class="custom-control custom-switch mr-2 mb-1">
                                                                <p class="mb-0">Website Status</p>
                                                                <input type="checkbox" class="custom-control-input"
                                                                       id="customSwitch3"
                                                                       value="1" <?php echo e($settings->web_status ? 'checked' : ''); ?>>
                                                                <label class="custom-control-label"
                                                                       for="customSwitch3"></label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12"> 
                                                        <div class="form-label-group">
                                                            <div class="custom-control custom-switch mr-2 mb-1">
                                                                <p class="mb-0">Maintenance</p>
                                                                <input type="checkbox" class="custom-control-input"
                                                                    id="customSwitch4"
                                                                    name="maintenance"
                                                                    value="1" <?php echo e($settings->maintenance ? 'checked' : ''); ?>>
                                                                <label class="custom-control-label"
                                                                    for="customSwitch4"></label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="app_ios_url" class="form-control"
                                                                   name="app_ios_url" placeholder="App store Link"
                                                                   value="<?php echo e($settings->app_ios_url); ?>">
                                                            <label for="company-column">App store Link (iOS)</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="app_android_url" class="form-control"
                                                                   name="app_android_url" placeholder="Play store Link"
                                                                   value="<?php echo e($settings->app_android_url); ?>">
                                                            <label for="company-column">Play store Link
                                                                (Android)</label>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="app_ios_version" class="form-control"
                                                                   name="app_ios_version" placeholder="App store Version"
                                                                   value="<?php echo e($settings->app_ios_version); ?>">
                                                            <label for="company-column">App store Version (iOS)</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="app_android_version" class="form-control"
                                                                   name="app_android_version" placeholder="Play store App Version"
                                                                   value="<?php echo e($settings->app_android_version); ?>">
                                                            <label for="company-column">Play store Version
                                                                (Android)</label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <p>
                                                <!-- <h3>Email Configuration</h3></p>

                                                <div class="row">
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="host" class="form-control"
                                                                   name="host" placeholder="Host"
                                                                   value="<?php echo e($settings->host); ?>">
                                                            <label for="host">Host</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="port" class="form-control"
                                                                   name="port" placeholder="Port"
                                                                   value="<?php echo e($settings->port); ?>">
                                                            <label for="host">Port</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="port" class="form-control"
                                                                   name="email" placeholder="Email"
                                                                   value="<?php echo e($settings->email); ?>">
                                                            <label for="host">Email</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="from_name" class="form-control"
                                                                   name="from_name" placeholder="Email From Name"
                                                                   value="<?php echo e($settings->from_name); ?>">
                                                            <label for="host">Email From Name</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="smtp_password" class="form-control"
                                                                   name="smtp_password" placeholder="SMTP Password"
                                                                   value="<?php echo e($settings->smtp_password); ?>">
                                                            <label for="host">SMTP Password</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-12">
                                                        <div class="form-label-group">
                                                            <input type="text" id="smtp_encryption" class="form-control"
                                                                   name="smtp_encryption" placeholder="SMTP Encryption"
                                                                   value="<?php echo e($settings->smtp_encryption); ?>">
                                                            <label for="host">SMTP Encryption</label>
                                                        </div>
                                                    </div>
                                                </div> -->

                                                <div>&nbsp;</div>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-primary mr-1 mb-1">Save
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Form Ends -->

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        <?php if(session('success')): ?>
        toastr.success('<?php echo e(session('success')); ?>', 'Success');
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\tharbricks\resources\views/admin/settings/settings.blade.php ENDPATH**/ ?>