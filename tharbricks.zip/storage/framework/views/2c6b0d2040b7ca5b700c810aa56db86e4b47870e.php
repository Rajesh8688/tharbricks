 <!-- BEGIN: Main Menu-->
 <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(route('admin.dashboard')); ?>">
                    <div class="brand-logo"></div>
                    <h2 class="brand-text mb-0"><?php echo e(env("APP_NAME")); ?></h2>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="icon-disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'dashboard' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="feather icon-home"></i><span class="menu-title" data-i18n="Dashboard">Dashboard</span><span class="badge badge badge-warning badge-pill float-right mr-2"></span></a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'bookings' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.bookingsList')); ?>"><i class="feather icon-message-square"></i><span class="menu-title" data-i18n="Booking">Flight Booking</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hotel-booking-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'hotelBookings' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.hotelbookingsList')); ?>"><i class="feather icon-message-square"></i><span class="menu-title" data-i18n="Booking">Hotel Booking</span></a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'customer' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.customerList')); ?>"><i class="feather icon-mail"></i><span class="menu-title" data-i18n="Customers">Customers</span></a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'user' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.userList')); ?>"><i class="feather icon-message-square"></i><span class="menu-title" data-i18n="Users">Users</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'category' ? 'active' : ''); ?>"><a href="<?php echo e(route('category.index')); ?>"><i class="feather icon-calendar"></i><span class="menu-title" data-i18n="Categories">Category</span></a>
            </li>
            
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('popular-events-news-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'popular-events-news' ? 'active' : ''); ?>"><a href="<?php echo e(route('popular-events-news.index')); ?>"><i class="feather icon-calendar"></i><span class="menu-title" data-i18n="Offers">Popular Events News</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupone-view')): ?>
            <li class=" nav-item"><a href="#"><i class="feather icon-message-square"></i><span class="menu-title" data-i18n="Coupones">Coupones</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('package-view')): ?>
            
            <li class=" nav-item <?php echo e(Request::segment(2) == 'packages' ? 'active' : ''); ?>"><a href="<?php echo e(route('packages.index')); ?>"><i class="feather icon-calendar"></i><span class="menu-title" data-i18n="Packages">Packages</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destination-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'destinations' ? 'active' : ''); ?>"><a href="<?php echo e(route('destinations.index')); ?>"><i class="feather icon-check-square"></i><span class="menu-title" data-i18n="Destinations">Destinations</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['faq-view' , 'privacy-policy-view'])): ?>
            <li class=" navigation-header"><span>pages</span>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'faq' ? 'active' : ''); ?>"><a href="<?php echo e(route('faq.index')); ?>"><i class="feather icon-help-circle"></i><span class="menu-title" data-i18n="FAQ">FAQ</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('privacy-policy-view')): ?>
            <li class=" nav-item"><a href="#"><i class="feather icon-info"></i><span class="menu-title" data-i18n="Knowledge Base">Privacy Policy</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['role-view', 'operator-view' , 'currency-view' , 'markups-view' , 'app-view' ,'push-notification-view'])): ?>
            <li class=" navigation-header"><span>Settings</span></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-view')): ?>
            <li class="nav-item <?php echo e(Request::segment(2) == 'role' ? 'active' : ''); ?>"><a
                href="<?php echo e(route('role.index')); ?>"><i class="feather icon-user-plus"></i><span
                    class="menu-title"
                    data-i18n="Roles">Roles</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operator-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'operator' ? 'active' : ''); ?>"><a href="<?php echo e(route('operator.index')); ?>"><i class="feather icon-mail"></i><span class="menu-title" data-i18n="Operators">Operators</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('currency-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'currency' ? 'active' : ''); ?>"><a href="<?php echo e(route('currency.index')); ?>"><i class="feather icon-calendar"></i><span class="menu-title" data-i18n="<?php echo e(__('admin.currency')); ?>"><?php echo e(__('admin.currency')); ?></span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('markups-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'markups' ? 'active' : ''); ?>"><a href="<?php echo e(route('markups.index')); ?>"><i class="feather icon-mail"></i><span class="menu-title" data-i18n="Mark Ups">Mark Ups</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('app-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'app' ? 'active' : ''); ?>"><a href="<?php echo e(route('app.index')); ?>"><i class="feather icon-mail"></i><span class="menu-title" data-i18n="App">App</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('push-notification-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'notifications' ? 'active' : ''); ?>"><a href="<?php echo e(route('notifications.index')); ?>"><i class="feather icon-mail"></i><span class="menu-title" data-i18n="Notifications">Notifications</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-view')): ?>
            <li class=" nav-item <?php echo e(Request::segment(2) == 'settings' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.settings.show')); ?>"><i class="feather icon-settings"></i><span class="menu-title" data-i18n="General">General</span></a>
            </li>
            <?php endif; ?>
            
           
        </ul>
    </div>
</div>
<!-- END: Main Menu--><?php /**PATH D:\wamp64\www\tharbricks\resources\views/admin/layouts/menu.blade.php ENDPATH**/ ?>