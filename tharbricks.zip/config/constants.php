<?php

return [
    'NO_IMG_ADMIN' => 'images/noimage.png',
];
